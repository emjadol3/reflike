import React, { useState } from 'react';
import { Play, Eye, ThumbsUp, Clock, DollarSign, TrendingUp, Upload } from 'lucide-react';

const Videos: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('trending');

  const categories = [
    { id: 'trending', name: 'Trending', icon: TrendingUp },
    { id: 'education', name: 'Education', icon: null },
    { id: 'entertainment', name: 'Entertainment', icon: null },
    { id: 'lifestyle', name: 'Lifestyle', icon: null },
    { id: 'tech', name: 'Technology', icon: null },
  ];

  const videos = [
    {
      id: 1,
      title: 'Complete React Tutorial for Beginners 2024',
      creator: 'CodeMaster Pro',
      thumbnail: 'https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      duration: '2:45:30',
      views: 125000,
      likes: 8900,
      earnings: '$1,250.80',
      uploadDate: '3 days ago',
      category: 'education'
    },
    {
      id: 2,
      title: 'Amazing Street Food Around the World',
      creator: 'Foodie Adventures',
      thumbnail: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      duration: '15:22',
      views: 89000,
      likes: 5600,
      earnings: '$890.45',
      uploadDate: '1 day ago',
      category: 'lifestyle'
    },
    {
      id: 3,
      title: 'Latest iPhone 15 Pro Max Review',
      creator: 'Tech Reviews Daily',
      thumbnail: 'https://images.pexels.com/photos/147413/twitter-facebook-together-exchange-of-information-147413.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      duration: '18:45',
      views: 245000,
      likes: 12000,
      earnings: '$2,150.30',
      uploadDate: '5 days ago',
      category: 'tech'
    },
    {
      id: 4,
      title: 'Comedy Sketch: When AI Takes Over',
      creator: 'Laugh Factory',
      thumbnail: 'https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      duration: '8:30',
      views: 156000,
      likes: 9800,
      earnings: '$1,450.60',
      uploadDate: '2 days ago',
      category: 'entertainment'
    },
    {
      id: 5,
      title: 'Minimalist Home Tour & Design Tips',
      creator: 'Interior Inspirations',
      thumbnail: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      duration: '12:15',
      views: 67000,
      likes: 4200,
      earnings: '$620.25',
      uploadDate: '4 days ago',
      category: 'lifestyle'
    },
    {
      id: 6,
      title: 'Machine Learning Explained Simply',
      creator: 'AI Academy',
      thumbnail: 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      duration: '25:40',
      views: 198000,
      likes: 11500,
      earnings: '$1,890.75',
      uploadDate: '1 week ago',
      category: 'education'
    }
  ];

  const formatViews = (views: number) => {
    if (views >= 1000000) return `${(views / 1000000).toFixed(1)}M`;
    if (views >= 1000) return `${(views / 1000).toFixed(1)}K`;
    return views.toString();
  };

  return (
    <div className="max-w-7xl mx-auto">
      {/* Upload Section */}
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl p-6 mb-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold mb-2">Share Your Story</h2>
            <p className="text-purple-100">Upload videos and start earning from your content today!</p>
          </div>
          <button className="bg-white text-purple-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-all duration-200 flex items-center space-x-2">
            <Upload className="h-5 w-5" />
            <span>Upload Video</span>
          </button>
        </div>
      </div>

      {/* Categories */}
      <div className="flex space-x-4 mb-8 overflow-x-auto pb-2">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => setSelectedCategory(category.id)}
            className={`flex items-center space-x-2 px-4 py-2 rounded-full whitespace-nowrap transition-all duration-200 ${
              selectedCategory === category.id
                ? 'bg-purple-600 text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            {category.icon && <category.icon className="h-4 w-4" />}
            <span>{category.name}</span>
          </button>
        ))}
      </div>

      {/* Video Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {videos.map((video) => (
          <div key={video.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-lg transition-all duration-200 group">
            {/* Thumbnail */}
            <div className="relative">
              <img
                src={video.thumbnail}
                alt={video.title}
                className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-200"
              />
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 flex items-center justify-center transition-all duration-200">
                <button className="w-12 h-12 bg-white bg-opacity-90 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-200">
                  <Play className="h-6 w-6 text-gray-800 ml-1" />
                </button>
              </div>
              <div className="absolute bottom-2 right-2 bg-black bg-opacity-70 text-white px-2 py-1 rounded text-sm">
                {video.duration}
              </div>
            </div>

            {/* Content */}
            <div className="p-4">
              <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2 group-hover:text-purple-600 transition-colors duration-200">
                {video.title}
              </h3>
              <p className="text-sm text-gray-600 mb-3">{video.creator}</p>
              
              {/* Stats */}
              <div className="flex items-center justify-between text-sm text-gray-500 mb-3">
                <div className="flex items-center space-x-4">
                  <span className="flex items-center space-x-1">
                    <Eye className="h-4 w-4" />
                    <span>{formatViews(video.views)}</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <ThumbsUp className="h-4 w-4" />
                    <span>{formatViews(video.likes)}</span>
                  </span>
                </div>
                <span className="flex items-center space-x-1">
                  <Clock className="h-4 w-4" />
                  <span>{video.uploadDate}</span>
                </span>
              </div>

              {/* Earnings */}
              <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                <span className="text-xs text-gray-500">Creator Earnings</span>
                <span className="flex items-center space-x-1 text-green-600 font-semibold">
                  <DollarSign className="h-4 w-4" />
                  <span>{video.earnings}</span>
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Videos;