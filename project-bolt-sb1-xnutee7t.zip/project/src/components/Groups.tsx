import React, { useState } from 'react'
import { Users, Plus, Search, Globe, Lock, Crown, MessageCircle, Calendar, TrendingUp, Star } from 'lucide-react'

const Groups: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('all')

  const categories = [
    { id: 'all', name: 'All Groups' },
    { id: 'technology', name: 'Technology' },
    { id: 'business', name: 'Business' },
    { id: 'lifestyle', name: 'Lifestyle' },
    { id: 'education', name: 'Education' },
    { id: 'entertainment', name: 'Entertainment' },
  ]

  const groups = [
    {
      id: 1,
      name: 'Digital Marketing Masters',
      description: 'Learn advanced digital marketing strategies and grow your business online',
      cover: 'https://images.pexels.com/photos/265087/pexels-photo-265087.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      members: 12450,
      posts: 1250,
      privacy: 'public' as const,
      category: 'business',
      admin: 'Sarah Johnson',
      growth: '+15%',
      active: '2h ago'
    },
    {
      id: 2,
      name: 'React Developers Community',
      description: 'Connect with React developers worldwide and share knowledge',
      cover: 'https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      members: 8900,
      posts: 890,
      privacy: 'public' as const,
      category: 'technology',
      admin: 'Alex Chen',
      growth: '+22%',
      active: '1h ago'
    },
    {
      id: 3,
      name: 'Fitness & Wellness Hub',
      description: 'Your journey to a healthier lifestyle starts here',
      cover: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      members: 15600,
      posts: 2100,
      privacy: 'private' as const,
      category: 'lifestyle',
      admin: 'Mike Rodriguez',
      growth: '+8%',
      active: '30m ago'
    },
    {
      id: 4,
      name: 'Crypto Trading Signals',
      description: 'Premium trading signals and market analysis',
      cover: 'https://images.pexels.com/photos/8369648/pexels-photo-8369648.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      members: 5670,
      posts: 450,
      privacy: 'private' as const,
      category: 'business',
      admin: 'David Kim',
      growth: '+35%',
      active: '15m ago'
    },
    {
      id: 5,
      name: 'Photography Masterclass',
      description: 'Learn professional photography techniques and showcase your work',
      cover: 'https://images.pexels.com/photos/1591056/pexels-photo-1591056.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      members: 9800,
      posts: 1800,
      privacy: 'public' as const,
      category: 'education',
      admin: 'Emma Wilson',
      growth: '+12%',
      active: '45m ago'
    },
    {
      id: 6,
      name: 'Movie Buffs United',
      description: 'Discuss latest movies, reviews, and entertainment news',
      cover: 'https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      members: 11200,
      posts: 950,
      privacy: 'public' as const,
      category: 'entertainment',
      admin: 'James Brown',
      growth: '+6%',
      active: '3h ago'
    }
  ]

  const myGroups = [
    { id: 1, name: 'Digital Marketing Masters', avatar: '🚀', unread: 5 },
    { id: 2, name: 'React Developers', avatar: '⚛️', unread: 12 },
    { id: 3, name: 'Fitness Hub', avatar: '💪', unread: 3 },
  ]

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`
    return num.toString()
  }

  const filteredGroups = selectedCategory === 'all' 
    ? groups 
    : groups.filter(group => group.category === selectedCategory)

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 rounded-2xl p-8 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold mb-3">Discover Groups</h1>
              <p className="text-indigo-100 text-lg">Connect with like-minded people and grow together</p>
              <div className="flex items-center space-x-6 mt-4">
                <div className="flex items-center space-x-2">
                  <Users className="h-5 w-5" />
                  <span>50K+ Active Members</span>
                </div>
                <div className="flex items-center space-x-2">
                  <MessageCircle className="h-5 w-5" />
                  <span>1M+ Discussions</span>
                </div>
              </div>
            </div>
            <button className="bg-white/20 backdrop-blur-sm text-white px-6 py-3 rounded-xl hover:bg-white/30 transition-all duration-200 flex items-center space-x-2 border border-white/20">
              <Plus className="h-5 w-5" />
              <span>Create Group</span>
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Sidebar */}
        <div className="lg:col-span-1 space-y-6">
          {/* My Groups */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <h3 className="font-bold text-gray-900 mb-4 flex items-center space-x-2">
              <Users className="h-5 w-5 text-purple-600" />
              <span>My Groups</span>
            </h3>
            <div className="space-y-3">
              {myGroups.map((group) => (
                <div key={group.id} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-xl transition-all duration-200 cursor-pointer">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center text-white font-bold">
                      {group.avatar}
                    </div>
                    <div>
                      <p className="font-medium text-gray-900 text-sm">{group.name}</p>
                    </div>
                  </div>
                  {group.unread > 0 && (
                    <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">{group.unread}</span>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Quick Stats */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <h3 className="font-bold text-gray-900 mb-4">Your Activity</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Groups Joined</span>
                <span className="font-bold text-purple-600">12</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Posts This Week</span>
                <span className="font-bold text-green-600">8</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Reputation</span>
                <div className="flex items-center space-x-1">
                  <Star className="h-4 w-4 text-yellow-500 fill-current" />
                  <span className="font-bold text-yellow-600">4.8</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3 space-y-6">
          {/* Search & Filters */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search groups..."
                className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 bg-gray-50 focus:bg-white"
              />
            </div>
          </div>

          {/* Categories */}
          <div className="flex space-x-3 overflow-x-auto pb-2">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-6 py-2 rounded-full whitespace-nowrap transition-all duration-200 ${
                  selectedCategory === category.id
                    ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>

          {/* Groups Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredGroups.map((group) => (
              <div key={group.id} className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-lg transition-all duration-300 group">
                {/* Cover Image */}
                <div className="relative h-40">
                  <img
                    src={group.cover}
                    alt={group.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                  <div className="absolute top-4 left-4 flex items-center space-x-2">
                    {group.privacy === 'public' ? (
                      <div className="bg-green-500 text-white px-2 py-1 rounded-full text-xs flex items-center space-x-1">
                        <Globe className="h-3 w-3" />
                        <span>Public</span>
                      </div>
                    ) : (
                      <div className="bg-orange-500 text-white px-2 py-1 rounded-full text-xs flex items-center space-x-1">
                        <Lock className="h-3 w-3" />
                        <span>Private</span>
                      </div>
                    )}
                  </div>
                  <div className="absolute top-4 right-4">
                    <div className="bg-white/20 backdrop-blur-sm text-white px-2 py-1 rounded-full text-xs flex items-center space-x-1">
                      <TrendingUp className="h-3 w-3" />
                      <span>{group.growth}</span>
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <div className="flex items-start justify-between mb-3">
                    <h3 className="font-bold text-gray-900 text-lg group-hover:text-purple-600 transition-colors duration-200">
                      {group.name}
                    </h3>
                    <div className="flex items-center space-x-1 text-yellow-500">
                      <Crown className="h-4 w-4" />
                    </div>
                  </div>
                  
                  <p className="text-gray-600 mb-4 line-clamp-2">{group.description}</p>
                  
                  <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                    <div className="flex items-center space-x-4">
                      <span className="flex items-center space-x-1">
                        <Users className="h-4 w-4" />
                        <span>{formatNumber(group.members)} members</span>
                      </span>
                      <span className="flex items-center space-x-1">
                        <MessageCircle className="h-4 w-4" />
                        <span>{formatNumber(group.posts)} posts</span>
                      </span>
                    </div>
                    <span className="flex items-center space-x-1">
                      <Calendar className="h-4 w-4" />
                      <span>{group.active}</span>
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="text-xs text-gray-500">
                      Admin: <span className="font-medium text-gray-700">{group.admin}</span>
                    </div>
                    <button className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-2 rounded-lg hover:from-purple-700 hover:to-pink-700 transition-all duration-200 text-sm font-medium">
                      {group.privacy === 'public' ? 'Join Group' : 'Request to Join'}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

export default Groups