import React, { useState } from 'react';
import { Heart, MessageCircle, Share2, Bookmark, MoreHorizontal, Play, DollarSign, Gift } from 'lucide-react';

interface FeedProps {
  user: any;
}

const Feed: React.FC<FeedProps> = ({ user }) => {
  const [likedPosts, setLikedPosts] = useState<Set<number>>(new Set());
  const [savedPosts, setSavedPosts] = useState<Set<number>>(new Set());

  const toggleLike = (postId: number) => {
    const newLiked = new Set(likedPosts);
    if (newLiked.has(postId)) {
      newLiked.delete(postId);
    } else {
      newLiked.add(postId);
    }
    setLikedPosts(newLiked);
  };

  const toggleSave = (postId: number) => {
    const newSaved = new Set(savedPosts);
    if (newSaved.has(postId)) {
      newSaved.delete(postId);
    } else {
      newSaved.add(postId);
    }
    setSavedPosts(newSaved);
  };

  const posts = [
    {
      id: 1,
      user: { name: 'Alex Rodriguez', avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop', verified: true },
      type: 'video',
      content: 'Just dropped my latest cooking tutorial! 🍳 Learn how to make the perfect pasta carbonara in under 20 minutes.',
      videoThumbnail: 'https://images.pexels.com/photos/1279330/pexels-photo-1279330.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      duration: '12:45',
      likes: 1247,
      comments: 89,
      shares: 23,
      timestamp: '2 hours ago',
      monetized: true,
      earnings: '$45.20'
    },
    {
      id: 2,
      user: { name: 'Maya Chen', avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop', verified: false },
      type: 'image',
      content: 'Amazing sunset from my weekend hiking trip! Nature never fails to inspire ✨',
      image: 'https://images.pexels.com/photos/1118873/pexels-photo-1118873.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&fit=crop',
      likes: 892,
      comments: 45,
      shares: 12,
      timestamp: '4 hours ago',
      monetized: false
    },
    {
      id: 3,
      user: { name: 'David Kim', avatar: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop', verified: true },
      type: 'video',
      content: 'Tech Review: The new smartphone that\'s changing everything! Full breakdown and honest thoughts.',
      videoThumbnail: 'https://images.pexels.com/photos/147413/twitter-facebook-together-exchange-of-information-147413.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      duration: '18:30',
      likes: 2156,
      comments: 234,
      shares: 67,
      timestamp: '6 hours ago',
      monetized: true,
      earnings: '$128.50'
    }
  ];

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* Create Post */}
      {user && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-4">
            <img
              src={user.avatar}
              alt="Your avatar"
              className="w-10 h-10 rounded-full object-cover"
            />
            <input
              type="text"
              placeholder="What's on your mind?"
              className="flex-1 bg-gray-100 rounded-full px-4 py-3 text-gray-700 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all duration-200"
            />
          </div>
          <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100">
            <div className="flex space-x-4">
              <button className="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-all duration-200">
                <Play className="h-5 w-5 text-red-500" />
                <span>Video</span>
              </button>
              <button className="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-all duration-200">
                <Gift className="h-5 w-5 text-green-500" />
                <span>Product</span>
              </button>
            </div>
            <button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-6 py-2 rounded-lg hover:from-purple-700 hover:to-blue-700 transition-all duration-200">
              Post
            </button>
          </div>
        </div>
      )}

      {/* Posts */}
      {posts.map((post) => (
        <div key={post.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-all duration-200">
          {/* Post Header */}
          <div className="p-6 pb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <img
                  src={post.user.avatar}
                  alt={post.user.name}
                  className="w-10 h-10 rounded-full object-cover"
                />
                <div>
                  <div className="flex items-center space-x-1">
                    <h3 className="font-semibold text-gray-900">{post.user.name}</h3>
                    {post.user.verified && (
                      <div className="w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                        <div className="w-2 h-2 bg-white rounded-full"></div>
                      </div>
                    )}
                  </div>
                  <p className="text-sm text-gray-500">{post.timestamp}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                {post.monetized && (
                  <div className="flex items-center space-x-1 bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs">
                    <DollarSign className="h-3 w-3" />
                    <span>{post.earnings}</span>
                  </div>
                )}
                <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full transition-all duration-200">
                  <MoreHorizontal className="h-5 w-5" />
                </button>
              </div>
            </div>
            <p className="text-gray-800 mt-3">{post.content}</p>
          </div>

          {/* Media */}
          {post.type === 'video' ? (
            <div className="relative">
              <img
                src={post.videoThumbnail}
                alt="Video thumbnail"
                className="w-full h-64 object-cover"
              />
              <div className="absolute inset-0 bg-black bg-opacity-20 flex items-center justify-center">
                <button className="w-16 h-16 bg-white bg-opacity-90 rounded-full flex items-center justify-center hover:bg-opacity-100 transition-all duration-200">
                  <Play className="h-8 w-8 text-gray-800 ml-1" />
                </button>
              </div>
              <div className="absolute bottom-4 right-4 bg-black bg-opacity-70 text-white px-2 py-1 rounded text-sm">
                {post.duration}
              </div>
            </div>
          ) : (
            <img
              src={post.image}
              alt="Post content"
              className="w-full h-64 object-cover"
            />
          )}

          {/* Post Actions */}
          <div className="p-6 pt-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-6">
                <button
                  onClick={() => toggleLike(post.id)}
                  className={`flex items-center space-x-2 transition-all duration-200 ${
                    likedPosts.has(post.id) ? 'text-red-500' : 'text-gray-600 hover:text-red-500'
                  }`}
                >
                  <Heart className={`h-5 w-5 ${likedPosts.has(post.id) ? 'fill-current' : ''}`} />
                  <span className="text-sm font-medium">{post.likes}</span>
                </button>
                <button className="flex items-center space-x-2 text-gray-600 hover:text-blue-500 transition-all duration-200">
                  <MessageCircle className="h-5 w-5" />
                  <span className="text-sm font-medium">{post.comments}</span>
                </button>
                <button className="flex items-center space-x-2 text-gray-600 hover:text-green-500 transition-all duration-200">
                  <Share2 className="h-5 w-5" />
                  <span className="text-sm font-medium">{post.shares}</span>
                </button>
              </div>
              <button
                onClick={() => toggleSave(post.id)}
                className={`transition-all duration-200 ${
                  savedPosts.has(post.id) ? 'text-purple-500' : 'text-gray-600 hover:text-purple-500'
                }`}
              >
                <Bookmark className={`h-5 w-5 ${savedPosts.has(post.id) ? 'fill-current' : ''}`} />
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Feed;