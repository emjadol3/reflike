import React, { useState } from 'react';
import { X, Camera, MapPin, Calendar, Link as LinkIcon, Edit3, Settings, Share2, MessageCircle, UserPlus, Users, Video, Image, Grid, Heart, Eye } from 'lucide-react';

interface UserProfileProps {
  isOpen: boolean;
  onClose: () => void;
  user: any;
  isOwnProfile?: boolean;
}

const UserProfile: React.FC<UserProfileProps> = ({ isOpen, onClose, user, isOwnProfile = true }) => {
  const [activeTab, setActiveTab] = useState('posts');
  const [isFollowing, setIsFollowing] = useState(false);

  if (!isOpen || !user) return null;

  const tabs = [
    { id: 'posts', name: 'Posts', icon: Grid },
    { id: 'videos', name: 'Videos', icon: Video },
    { id: 'photos', name: 'Photos', icon: Image },
  ];

  const userPosts = [
    {
      id: 1,
      type: 'video',
      thumbnail: 'https://images.pexels.com/photos/1279330/pexels-photo-1279330.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
      likes: 1247,
      views: 15600,
      duration: '12:45'
    },
    {
      id: 2,
      type: 'image',
      thumbnail: 'https://images.pexels.com/photos/1118873/pexels-photo-1118873.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
      likes: 892,
      views: 5400
    },
    {
      id: 3,
      type: 'video',
      thumbnail: 'https://images.pexels.com/photos/147413/twitter-facebook-together-exchange-of-information-147413.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
      likes: 2156,
      views: 28900,
      duration: '18:30'
    },
    {
      id: 4,
      type: 'image',
      thumbnail: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
      likes: 567,
      views: 3200
    },
    {
      id: 5,
      type: 'video',
      thumbnail: 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
      likes: 1890,
      views: 22100,
      duration: '25:40'
    },
    {
      id: 6,
      type: 'image',
      thumbnail: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop',
      likes: 734,
      views: 4800
    }
  ];

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="relative">
          {/* Cover Photo */}
          <div className="h-48 bg-gradient-to-r from-purple-600 via-blue-600 to-teal-600 relative">
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 text-white hover:bg-white hover:bg-opacity-20 rounded-full transition-all duration-200"
            >
              <X className="h-6 w-6" />
            </button>
            {isOwnProfile && (
              <button className="absolute bottom-4 right-4 p-2 text-white hover:bg-white hover:bg-opacity-20 rounded-full transition-all duration-200">
                <Camera className="h-5 w-5" />
              </button>
            )}
          </div>

          {/* Profile Info */}
          <div className="px-8 pb-6">
            <div className="flex flex-col md:flex-row md:items-end md:justify-between -mt-16 relative">
              <div className="flex flex-col md:flex-row md:items-end space-y-4 md:space-y-0 md:space-x-6">
                {/* Avatar */}
                <div className="relative">
                  <img
                    src={user.avatar}
                    alt={user.name}
                    className="w-32 h-32 rounded-full border-4 border-white object-cover shadow-lg"
                  />
                  {isOwnProfile && (
                    <button className="absolute bottom-2 right-2 p-2 bg-purple-600 text-white rounded-full hover:bg-purple-700 transition-all duration-200">
                      <Camera className="h-4 w-4" />
                    </button>
                  )}
                  {user.verified && (
                    <div className="absolute -top-1 -right-1 w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center border-2 border-white">
                      <div className="w-4 h-4 bg-white rounded-full"></div>
                    </div>
                  )}
                </div>

                {/* User Info */}
                <div className="text-center md:text-left">
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">{user.name}</h1>
                  <p className="text-gray-600 mb-3">@{user.email.split('@')[0]}</p>
                  <div className="flex items-center justify-center md:justify-start space-x-6 text-sm text-gray-600 mb-4">
                    <div className="flex items-center space-x-1">
                      <MapPin className="h-4 w-4" />
                      <span>San Francisco, CA</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Calendar className="h-4 w-4" />
                      <span>Joined March 2023</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <LinkIcon className="h-4 w-4" />
                      <a href="#" className="text-purple-600 hover:text-purple-700">website.com</a>
                    </div>
                  </div>
                  <p className="text-gray-700 max-w-md">
                    Content creator passionate about technology, education, and helping others grow. 
                    Building the future one video at a time! 🚀
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center space-x-3 mt-6 md:mt-0">
                {isOwnProfile ? (
                  <>
                    <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-all duration-200">
                      <Edit3 className="h-4 w-4" />
                      <span>Edit Profile</span>
                    </button>
                    <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-all duration-200">
                      <Settings className="h-4 w-4" />
                      <span>Settings</span>
                    </button>
                  </>
                ) : (
                  <>
                    <button
                      onClick={() => setIsFollowing(!isFollowing)}
                      className={`flex items-center space-x-2 px-6 py-2 rounded-lg font-semibold transition-all duration-200 ${
                        isFollowing
                          ? 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                          : 'bg-gradient-to-r from-purple-600 to-blue-600 text-white hover:from-purple-700 hover:to-blue-700'
                      }`}
                    >
                      <UserPlus className="h-4 w-4" />
                      <span>{isFollowing ? 'Following' : 'Follow'}</span>
                    </button>
                    <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-all duration-200">
                      <MessageCircle className="h-4 w-4" />
                      <span>Message</span>
                    </button>
                    <button className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-all duration-200">
                      <Share2 className="h-4 w-4" />
                    </button>
                  </>
                )}
              </div>
            </div>

            {/* Stats */}
            <div className="flex items-center justify-center md:justify-start space-x-8 mt-6 pt-6 border-t border-gray-200">
              <div className="text-center">
                <p className="text-2xl font-bold text-gray-900">{formatNumber(user.posts)}</p>
                <p className="text-gray-600">Posts</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-gray-900">{formatNumber(user.followers)}</p>
                <p className="text-gray-600">Followers</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-gray-900">{formatNumber(user.following)}</p>
                <p className="text-gray-600">Following</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-gray-900">4.8M</p>
                <p className="text-gray-600">Total Views</p>
              </div>
            </div>
          </div>
        </div>

        {/* Content Tabs */}
        <div className="border-t border-gray-200">
          <div className="flex space-x-8 px-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 py-4 border-b-2 transition-all duration-200 ${
                  activeTab === tab.id
                    ? 'border-purple-600 text-purple-600'
                    : 'border-transparent text-gray-600 hover:text-gray-900'
                }`}
              >
                <tab.icon className="h-4 w-4" />
                <span className="font-medium">{tab.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Content Grid */}
        <div className="p-8 max-h-96 overflow-y-auto">
          <div className="grid grid-cols-3 gap-4">
            {userPosts.map((post) => (
              <div key={post.id} className="relative group cursor-pointer">
                <img
                  src={post.thumbnail}
                  alt="Post"
                  className="w-full h-32 object-cover rounded-lg"
                />
                
                {/* Overlay */}
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 rounded-lg transition-all duration-200 flex items-center justify-center">
                  <div className="opacity-0 group-hover:opacity-100 transition-all duration-200 flex items-center space-x-4 text-white">
                    <div className="flex items-center space-x-1">
                      <Heart className="h-4 w-4" />
                      <span className="text-sm">{formatNumber(post.likes)}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Eye className="h-4 w-4" />
                      <span className="text-sm">{formatNumber(post.views)}</span>
                    </div>
                  </div>
                </div>

                {/* Video Duration */}
                {post.type === 'video' && post.duration && (
                  <div className="absolute bottom-2 right-2 bg-black bg-opacity-70 text-white px-2 py-1 rounded text-xs">
                    {post.duration}
                  </div>
                )}

                {/* Post Type Icon */}
                <div className="absolute top-2 left-2">
                  {post.type === 'video' ? (
                    <Video className="h-4 w-4 text-white drop-shadow-lg" />
                  ) : (
                    <Image className="h-4 w-4 text-white drop-shadow-lg" />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserProfile;