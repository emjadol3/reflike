import React, { useState } from 'react';
import { ShoppingBag, Star, Heart, Filter, Search, Plus, Package, TrendingUp } from 'lucide-react';

const Marketplace: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [likedProducts, setLikedProducts] = useState<Set<number>>(new Set());

  const categories = [
    { id: 'all', name: 'All Products' },
    { id: 'digital', name: 'Digital Products' },
    { id: 'courses', name: 'Courses' },
    { id: 'merchandise', name: 'Merchandise' },
    { id: 'services', name: 'Services' },
  ];

  const products = [
    {
      id: 1,
      title: 'Complete Web Development Bootcamp',
      creator: 'CodeMaster Pro',
      image: 'https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&fit=crop',
      price: 199.99,
      originalPrice: 299.99,
      rating: 4.8,
      reviews: 1247,
      sales: 3450,
      category: 'courses',
      type: 'Course'
    },
    {
      id: 2,
      title: 'Premium Lightroom Presets Pack',
      creator: 'PhotoArtist Studio',
      image: 'https://images.pexels.com/photos/1591056/pexels-photo-1591056.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&fit=crop',
      price: 29.99,
      originalPrice: null,
      rating: 4.9,
      reviews: 892,
      sales: 2100,
      category: 'digital',
      type: 'Digital Asset'
    },
    {
      id: 3,
      title: 'SocialStream Official T-Shirt',
      creator: 'SocialStream Store',
      image: 'https://images.pexels.com/photos/8532616/pexels-photo-8532616.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&fit=crop',
      price: 24.99,
      originalPrice: null,
      rating: 4.6,
      reviews: 456,
      sales: 1200,
      category: 'merchandise',
      type: 'Apparel'
    },
    {
      id: 4,
      title: '1-on-1 Business Mentoring Session',
      creator: 'Success Coach Maria',
      image: 'https://images.pexels.com/photos/7688336/pexels-photo-7688336.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&fit=crop',
      price: 150.00,
      originalPrice: null,
      rating: 5.0,
      reviews: 234,
      sales: 567,
      category: 'services',
      type: 'Consultation'
    },
    {
      id: 5,
      title: 'Notion Productivity Templates',
      creator: 'ProductivityPro',
      image: 'https://images.pexels.com/photos/4164418/pexels-photo-4164418.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&fit=crop',
      price: 19.99,
      originalPrice: 39.99,
      rating: 4.7,
      reviews: 678,
      sales: 1890,
      category: 'digital',
      type: 'Templates'
    },
    {
      id: 6,
      title: 'AI Prompt Engineering Masterclass',
      creator: 'AI Expert John',
      image: 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&fit=crop',
      price: 149.99,
      originalPrice: 199.99,
      rating: 4.9,
      reviews: 543,
      sales: 890,
      category: 'courses',
      type: 'Course'
    }
  ];

  const toggleLike = (productId: number) => {
    const newLiked = new Set(likedProducts);
    if (newLiked.has(productId)) {
      newLiked.delete(productId);
    } else {
      newLiked.add(productId);
    }
    setLikedProducts(newLiked);
  };

  const filteredProducts = selectedCategory === 'all' 
    ? products 
    : products.filter(product => product.category === selectedCategory);

  return (
    <div className="max-w-7xl mx-auto">
      {/* Header Section */}
      <div className="bg-gradient-to-r from-emerald-600 to-teal-600 rounded-xl p-8 mb-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Creator Marketplace</h1>
            <p className="text-emerald-100 text-lg">Discover amazing products from your favorite creators</p>
          </div>
          <button className="bg-white text-emerald-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-all duration-200 flex items-center space-x-2">
            <Plus className="h-5 w-5" />
            <span>Sell Product</span>
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-blue-100 rounded-lg">
              <Package className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">12,450</p>
              <p className="text-gray-600">Total Products</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-green-100 rounded-lg">
              <TrendingUp className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">$2.4M</p>
              <p className="text-gray-600">Creator Earnings</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-purple-100 rounded-lg">
              <ShoppingBag className="h-6 w-6 text-purple-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">89,230</p>
              <p className="text-gray-600">Happy Customers</p>
            </div>
          </div>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search products..."
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200"
          />
        </div>
        <div className="flex items-center space-x-4">
          <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-all duration-200">
            <Filter className="h-4 w-4" />
            <span>Filter</span>
          </button>
        </div>
      </div>

      {/* Categories */}
      <div className="flex space-x-4 mb-8 overflow-x-auto pb-2">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => setSelectedCategory(category.id)}
            className={`px-6 py-2 rounded-full whitespace-nowrap transition-all duration-200 ${
              selectedCategory === category.id
                ? 'bg-purple-600 text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            {category.name}
          </button>
        ))}
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProducts.map((product) => (
          <div key={product.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-lg transition-all duration-200 group">
            {/* Product Image */}
            <div className="relative">
              <img
                src={product.image}
                alt={product.title}
                className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-200"
              />
              <button
                onClick={() => toggleLike(product.id)}
                className={`absolute top-3 right-3 p-2 rounded-full transition-all duration-200 ${
                  likedProducts.has(product.id)
                    ? 'bg-red-500 text-white'
                    : 'bg-white text-gray-600 hover:bg-red-50 hover:text-red-500'
                }`}
              >
                <Heart className={`h-4 w-4 ${likedProducts.has(product.id) ? 'fill-current' : ''}`} />
              </button>
              <div className="absolute top-3 left-3 bg-purple-600 text-white px-2 py-1 rounded-full text-xs">
                {product.type}
              </div>
            </div>

            {/* Product Info */}
            <div className="p-6">
              <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2">{product.title}</h3>
              <p className="text-sm text-gray-600 mb-3">by {product.creator}</p>
              
              {/* Rating */}
              <div className="flex items-center space-x-2 mb-3">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${
                        i < Math.floor(product.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm text-gray-600">
                  {product.rating} ({product.reviews} reviews)
                </span>
              </div>

              {/* Price */}
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <span className="text-xl font-bold text-gray-900">${product.price}</span>
                  {product.originalPrice && (
                    <span className="text-sm text-gray-500 line-through">${product.originalPrice}</span>
                  )}
                </div>
                <span className="text-sm text-gray-500">{product.sales} sold</span>
              </div>

              {/* Action Button */}
              <button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white py-3 rounded-lg font-semibold hover:from-purple-700 hover:to-blue-700 transition-all duration-200 flex items-center justify-center space-x-2">
                <ShoppingBag className="h-4 w-4" />
                <span>Add to Cart</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Marketplace;