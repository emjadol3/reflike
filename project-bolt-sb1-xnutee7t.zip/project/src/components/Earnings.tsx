import React, { useState } from 'react';
import { DollarSign, TrendingUp, Eye, Users, Gift, CreditCard, Calendar, BarChart3 } from 'lucide-react';

const Earnings: React.FC = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('month');

  const periods = [
    { id: 'week', name: 'This Week' },
    { id: 'month', name: 'This Month' },
    { id: 'quarter', name: 'This Quarter' },
    { id: 'year', name: 'This Year' },
  ];

  const earningsData = {
    totalEarnings: 4567.89,
    thisMonth: 1234.56,
    growth: 23.5,
    videoEarnings: 2890.45,
    productSales: 1234.67,
    referralBonus: 442.77,
    avgPerView: 0.0034
  };

  const recentTransactions = [
    {
      id: 1,
      type: 'Video Revenue',
      description: 'React Tutorial Series - Ad Revenue',
      amount: 45.67,
      date: '2024-01-15',
      status: 'completed'
    },
    {
      id: 2,
      type: 'Product Sale',
      description: 'Web Development Course',
      amount: 199.99,
      date: '2024-01-14',
      status: 'completed'
    },
    {
      id: 3,
      type: 'Referral Bonus',
      description: 'New creator referral',
      amount: 25.00,
      date: '2024-01-13',
      status: 'completed'
    },
    {
      id: 4,
      type: 'Video Revenue',
      description: 'JavaScript Tips - Sponsorship',
      amount: 150.00,
      date: '2024-01-12',
      status: 'pending'
    },
    {
      id: 5,
      type: 'Product Sale',
      description: 'Lightroom Presets Pack',
      amount: 29.99,
      date: '2024-01-11',
      status: 'completed'
    }
  ];

  const monthlyData = [
    { month: 'Jan', earnings: 3200 },
    { month: 'Feb', earnings: 3800 },
    { month: 'Mar', earnings: 4100 },
    { month: 'Apr', earnings: 3900 },
    { month: 'May', earnings: 4500 },
    { month: 'Jun', earnings: 4567 }
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-600 to-emerald-600 rounded-xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Creator Dashboard</h1>
            <p className="text-green-100 text-lg">Track your earnings and grow your income</p>
          </div>
          <div className="text-right">
            <p className="text-green-100 text-sm">Total Earnings</p>
            <p className="text-4xl font-bold">${earningsData.totalEarnings.toLocaleString()}</p>
          </div>
        </div>
      </div>

      {/* Period Selector */}
      <div className="flex space-x-4 overflow-x-auto pb-2">
        {periods.map((period) => (
          <button
            key={period.id}
            onClick={() => setSelectedPeriod(period.id)}
            className={`px-6 py-2 rounded-full whitespace-nowrap transition-all duration-200 ${
              selectedPeriod === period.id
                ? 'bg-purple-600 text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            {period.name}
          </button>
        ))}
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">This Month</p>
              <p className="text-2xl font-bold text-gray-900">${earningsData.thisMonth.toLocaleString()}</p>
            </div>
            <div className="p-3 bg-green-100 rounded-lg">
              <DollarSign className="h-6 w-6 text-green-600" />
            </div>
          </div>
          <div className="flex items-center mt-3">
            <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-sm text-green-500">+{earningsData.growth}%</span>
            <span className="text-sm text-gray-500 ml-2">vs last month</span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Video Revenue</p>
              <p className="text-2xl font-bold text-gray-900">${earningsData.videoEarnings.toLocaleString()}</p>
            </div>
            <div className="p-3 bg-red-100 rounded-lg">
              <Eye className="h-6 w-6 text-red-600" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-sm text-gray-500">Avg per view: ${earningsData.avgPerView}</span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Product Sales</p>
              <p className="text-2xl font-bold text-gray-900">${earningsData.productSales.toLocaleString()}</p>
            </div>
            <div className="p-3 bg-blue-100 rounded-lg">
              <Gift className="h-6 w-6 text-blue-600" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-sm text-gray-500">45 products sold</span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Referral Bonus</p>
              <p className="text-2xl font-bold text-gray-900">${earningsData.referralBonus.toLocaleString()}</p>
            </div>
            <div className="p-3 bg-purple-100 rounded-lg">
              <Users className="h-6 w-6 text-purple-600" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-sm text-gray-500">12 referrals this month</span>
          </div>
        </div>
      </div>

      {/* Charts and Transactions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Earnings Chart */}
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Monthly Earnings</h3>
            <BarChart3 className="h-5 w-5 text-gray-500" />
          </div>
          <div className="h-64 flex items-end justify-between space-x-2">
            {monthlyData.map((data, index) => (
              <div key={index} className="flex flex-col items-center flex-1">
                <div
                  className="w-full bg-gradient-to-t from-purple-600 to-purple-400 rounded-t-md transition-all duration-300 hover:from-purple-700 hover:to-purple-500"
                  style={{ height: `${(data.earnings / 5000) * 100}%` }}
                ></div>
                <span className="text-xs text-gray-500 mt-2">{data.month}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Transactions */}
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Recent Transactions</h3>
            <button className="text-purple-600 hover:text-purple-700 text-sm font-medium">View All</button>
          </div>
          <div className="space-y-4">
            {recentTransactions.map((transaction) => (
              <div key={transaction.id} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg transition-all duration-200">
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-lg ${
                    transaction.type === 'Video Revenue' ? 'bg-red-100' :
                    transaction.type === 'Product Sale' ? 'bg-blue-100' :
                    'bg-purple-100'
                  }`}>
                    {transaction.type === 'Video Revenue' ? <Eye className="h-4 w-4 text-red-600" /> :
                     transaction.type === 'Product Sale' ? <Gift className="h-4 w-4 text-blue-600" /> :
                     <Users className="h-4 w-4 text-purple-600" />}
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{transaction.type}</p>
                    <p className="text-sm text-gray-600">{transaction.description}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-gray-900">+${transaction.amount}</p>
                  <div className="flex items-center space-x-2">
                    <span className={`inline-block w-2 h-2 rounded-full ${
                      transaction.status === 'completed' ? 'bg-green-500' : 'bg-yellow-500'
                    }`}></span>
                    <span className="text-xs text-gray-500 capitalize">{transaction.status}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Payout Section */}
      <div className="bg-white rounded-xl p-6 border border-gray-200">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Payout Settings</h3>
            <p className="text-gray-600">Manage your payment methods and withdrawal schedule</p>
          </div>
          <button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-purple-700 hover:to-blue-700 transition-all duration-200 flex items-center space-x-2">
            <CreditCard className="h-4 w-4" />
            <span>Request Payout</span>
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-4 border border-gray-200 rounded-lg">
            <div className="flex items-center space-x-3 mb-3">
              <CreditCard className="h-5 w-5 text-gray-600" />
              <span className="font-medium">Payment Method</span>
            </div>
            <p className="text-sm text-gray-600">PayPal (****@email.com)</p>
            <button className="text-purple-600 hover:text-purple-700 text-sm mt-2">Change</button>
          </div>
          
          <div className="p-4 border border-gray-200 rounded-lg">
            <div className="flex items-center space-x-3 mb-3">
              <Calendar className="h-5 w-5 text-gray-600" />
              <span className="font-medium">Payout Schedule</span>
            </div>
            <p className="text-sm text-gray-600">Monthly (1st of each month)</p>
            <button className="text-purple-600 hover:text-purple-700 text-sm mt-2">Change</button>
          </div>
          
          <div className="p-4 border border-gray-200 rounded-lg">
            <div className="flex items-center space-x-3 mb-3">
              <DollarSign className="h-5 w-5 text-gray-600" />
              <span className="font-medium">Available Balance</span>
            </div>
            <p className="text-lg font-bold text-gray-900">${earningsData.thisMonth.toLocaleString()}</p>
            <p className="text-sm text-gray-600 mt-1">Ready for payout</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Earnings;