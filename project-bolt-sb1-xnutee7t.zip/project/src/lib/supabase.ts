import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://your-project.supabase.co'
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'your-anon-key'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Database types
export interface User {
  id: string
  email: string
  name: string
  username: string
  avatar_url?: string
  cover_url?: string
  bio?: string
  location?: string
  website?: string
  verified: boolean
  followers_count: number
  following_count: number
  posts_count: number
  total_earnings: number
  created_at: string
}

export interface Post {
  id: string
  user_id: string
  content: string
  media_url?: string
  media_type?: 'image' | 'video'
  video_duration?: string
  likes_count: number
  comments_count: number
  shares_count: number
  views_count: number
  earnings: number
  monetized: boolean
  created_at: string
  user?: User
}

export interface Group {
  id: string
  name: string
  description: string
  cover_url?: string
  admin_id: string
  members_count: number
  privacy: 'public' | 'private'
  created_at: string
}

export interface Comment {
  id: string
  post_id: string
  user_id: string
  content: string
  likes_count: number
  created_at: string
  user?: User
}