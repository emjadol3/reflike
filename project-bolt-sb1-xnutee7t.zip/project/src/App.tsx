import React, { useState } from 'react'
import { useAuth } from './hooks/useAuth'
import Header from './components/Header'
import AuthModal from './components/AuthModal'
import UserProfile from './components/UserProfile'
import Feed from './components/Feed'
import Videos from './components/Videos'
import Groups from './components/Groups'
import Marketplace from './components/Marketplace'
import Earnings from './components/Earnings'

function App() {
  const { user, loading } = useAuth()
  const [activeTab, setActiveTab] = useState('feed')
  const [showAuthModal, setShowAuthModal] = useState(false)
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login')
  const [showProfile, setShowProfile] = useState(false)

  const handleAuthClick = () => {
    setAuthMode('login')
    setShowAuthModal(true)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 flex items-center justify-center">
        <div className="text-center">
          <div className="relative">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-600 via-purple-600 to-pink-500 rounded-2xl flex items-center justify-center shadow-lg animate-pulse">
              <span className="text-white font-bold text-2xl">R</span>
            </div>
            <div className="absolute -top-1 -right-1 w-6 h-6 bg-green-400 rounded-full border-2 border-white animate-bounce"></div>
          </div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-500 bg-clip-text text-transparent mt-4">
            RefLike
          </h1>
          <p className="text-gray-600 mt-2">Loading your experience...</p>
        </div>
      </div>
    )
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'feed':
        return <Feed />
      case 'videos':
        return <Videos />
      case 'groups':
        return <Groups />
      case 'marketplace':
        return <Marketplace />
      case 'earnings':
        return user ? <Earnings /> : (
          <div className="max-w-2xl mx-auto text-center py-16">
            <div className="bg-white rounded-2xl p-12 shadow-lg border border-gray-100">
              <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <span className="text-white text-3xl">💰</span>
              </div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Start Earning Today!</h2>
              <p className="text-gray-600 mb-8 text-lg">Join RefLike to track your revenue, manage payouts, and grow your income as a creator.</p>
              <button
                onClick={handleAuthClick}
                className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-500 text-white px-8 py-4 rounded-xl font-semibold hover:from-blue-700 hover:via-purple-700 hover:to-pink-600 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                Join RefLike Now
              </button>
            </div>
          </div>
        )
      default:
        return <Feed />
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header 
        activeTab={activeTab} 
        setActiveTab={setActiveTab}
        onAuthClick={handleAuthClick}
        onProfileClick={() => setShowProfile(true)}
      />
      <main className="py-8 px-4">
        {renderContent()}
      </main>
      
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        mode={authMode}
        onModeChange={setAuthMode}
      />
      
      {user && (
        <UserProfile
          isOpen={showProfile}
          onClose={() => setShowProfile(false)}
          user={user}
          isOwnProfile={true}
        />
      )}
    </div>
  )
}

export default App